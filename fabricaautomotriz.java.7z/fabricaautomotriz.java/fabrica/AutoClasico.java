package Fabrica;

public class AutoClasico  extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo, int precio, String radio, String agregarRadio) {
        super(color, marca, modelo, precio, radio, agregarRadio);
        
    }

    

    
    
}
