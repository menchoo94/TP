package Fabrica;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String color, String marca, String modelo, int precio, String radio, String agregarRadio) {
        super(color, marca, modelo, precio, radio, agregarRadio);
        
    }

   
}
