package Fabrica;
public abstract class Vehiculo{

    private String color;
    private String marca;
    private String modelo;
    private int precio;
    private String Radio;
    private String agregarRadio;
    
    
    public Vehiculo(String color, String marca, String modelo, int precio, String radio, String agregarRadio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        Radio = radio;
        this.agregarRadio = agregarRadio;
    }


    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", Radio=" + Radio + ", agregarRadio=" + agregarRadio + "]";
    }


    public String getColor() {
        return color;
    }


    public String getMarca() {
        return marca;
    }


    public String getModelo() {
        return modelo;
    }


    public int getPrecio() {
        return precio;
    }


    public String getRadio() {
        return Radio;
    }


    public String getAgregarRadio() {
        return agregarRadio;
    }


    public void setColor(String color) {
        this.color = color;
    }


    public void setMarca(String marca) {
        this.marca = marca;
    }


    public void setModelo(String modelo) {
        this.modelo = modelo;
    }


    public void setPrecio(int precio) {
        this.precio = precio;
    }


    public void setRadio(String radio) {
        Radio = radio;
    }


    public void setAgregarRadio(String agregarRadio) {
        this.agregarRadio = agregarRadio;
    }

    


    
}

