package Fabrica;

public final class Colectivo extends Vehiculo {

    public Colectivo(String color, String marca, String modelo, int precio, String radio, String agregarRadio) {
        super(color, marca, modelo, precio, radio, agregarRadio);
        
    }

    
}
