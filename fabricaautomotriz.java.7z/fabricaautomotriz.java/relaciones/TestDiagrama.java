package Relaciones;
import Fabrica.AutoClasico;
import Fabrica.AutoNuevo;
import Fabrica.Colectivo;
import Fabrica.Radio;


public class TestDiagrama {
    
    public static void main(String[] args) {
        AutoNuevo autoNuevo = new AutoNuevo("Rojo", "Lamborghini", "Huracan",
         150000000, "Radio Pionner", null);
        System.out.println(autoNuevo);
        
        AutoClasico autoClasico = new AutoClasico("Amarillo", "Chevrolet", "Camaro",
         30000000, null, "Philips");
        System.out.println(autoClasico);

        Colectivo colectivo = new Colectivo("Blanco", "Mercedes Benz", "Piso Bajo",
         15000000, null, "Sony");
        System.out.println(colectivo);

        Radio radio = new Radio("Pionner", 50);
        System.out.println(radio);

        Radio radio2 = new Radio("Philips", 25);
        System.out.println(radio2);

        Radio radio3 = new Radio("sony", 25);
        System.out.println(radio3);
    }

    
}




